# web-devlopment-news-and-weather-




a dynamic news and weather webpage using html, css, js.



to get news and weather data you need to create a account on api.openweathermap.org and newsapi.org to get your api key.




after creating a account and obtaining a api key , put api key of api.openweathermap.org in styles.css , and api key of newsapi.org in news.html.




replace PUT YOUR API KEY HERE with your api key.




after that you need to open the index.html with any compiler which support html and run it from there .




if you run the index.html directly it will not show data.



in index.html  you need to download the video from the link provided in the command and then renae it as video.mp4 and put it in the same folder as the projects.
